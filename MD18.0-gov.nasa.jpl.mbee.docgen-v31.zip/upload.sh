MD=MagicDrawUML1702-1
scp ./plugins/gov.nasa.jpl.mbee.docgen/DocGen-plugin.jar docgen:/data/www/magicdraw/$MD/plugins/gov.nasa.jpl.mbee.docgen/

MD=MagicDrawUML1702-2
scp ./plugins/gov.nasa.jpl.mbee.docgen/DocGen-plugin.jar docgen:/data/www/magicdraw/$MD/plugins/gov.nasa.jpl.mbee.docgen/

MD=MagicDrawUML1702-3
scp ./plugins/gov.nasa.jpl.mbee.docgen/DocGen-plugin.jar docgen:/data/www/magicdraw/$MD/plugins/gov.nasa.jpl.mbee.docgen/

MD=MagicDrawUML1702-4
scp ./plugins/gov.nasa.jpl.mbee.docgen/DocGen-plugin.jar docgen:/data/www/magicdraw/$MD/plugins/gov.nasa.jpl.mbee.docgen/
